package com.example.carros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
